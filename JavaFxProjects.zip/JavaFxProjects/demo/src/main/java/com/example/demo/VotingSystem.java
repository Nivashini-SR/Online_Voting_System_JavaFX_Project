package com.example.demo;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.time.Duration;


public class VotingSystem extends Application {
    private TableView<Candidate> candidateTable = new TableView<>();
    private ObservableList<Candidate> candidates = FXCollections.observableArrayList();
    private TextField nameField = new TextField();
    private TextField partyField = new TextField();
    private TextField usernameField = new TextField();
    private PasswordField passwordField = new PasswordField();

    private final String DB_URL = "jdbc:mysql://localhost:3306/voting_db";
    private final String DB_USER = "root";
    private final String DB_PASS = "28Dec2005*";

    private int loggedInUserId;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        showRoleSelectionScreen(primaryStage);
    }

    private void showRoleSelectionScreen(Stage stage) {
        VBox layout = new VBox(15);
        layout.getStyleClass().add("layout");

        Button adminButton = new Button("Login as Admin");
        Button voterButton = new Button("Login as Voter");

        adminButton.setOnAction(e -> showLoginScreen(stage, "admin"));
        voterButton.setOnAction(e -> showLoginScreen(stage, "voter"));

        layout.getChildren().addAll(new Label("Select Role"), adminButton, voterButton);

        Scene scene = new Scene(layout, 300, 200);
        scene.getStylesheets().add(getClass().getResource("/com/example/demo/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }


    private void showLoginScreen(Stage stage, String role) {
        VBox layout = new VBox(15);
        layout.getStyleClass().add("layout");

        TextField userField = new TextField();
        PasswordField passField = new PasswordField();

        if (role.equals("admin")) {
            userField.setPromptText("Username");
            passField.setPromptText("Password");
        } else {
            userField.setPromptText("Enter 12-digit Aadhar Number");
            passField.setPromptText("Enter 4-digit OTP");
        }

        Button loginButton = new Button("Login");
        loginButton.getStyleClass().add("button-primary");

        loginButton.setOnAction(e -> handleLogin(stage, role, userField.getText(), passField.getText()));

        layout.getChildren().addAll(
                new Label("Login as " + role.substring(0, 1).toUpperCase() + role.substring(1)),
                userField, passField, loginButton
        );

        Scene scene = new Scene(layout, 300, 200);
        scene.getStylesheets().add(getClass().getResource("/com/example/demo/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }


    private void handleLogin(Stage stage, String role, String usernameOrAadhar, String passwordOrOtp) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String query = "SELECT id FROM users WHERE username = ? AND password = ? AND role = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, usernameOrAadhar);
            stmt.setString(2, passwordOrOtp);
            stmt.setString(3, role);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                loggedInUserId = rs.getInt("id");
                if (role.equalsIgnoreCase("admin")) {
                    showAdminDashboard(stage);
                } else {
                    showVoterDashboard(stage);
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid credentials or role mismatch.");
                alert.show();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private void showAdminDashboard(Stage stage) {
        VBox layout = new VBox(10);
        layout.getStyleClass().add("layout");

        nameField.setPromptText("Candidate Name");
        partyField.setPromptText("Party Name");

        Button addButton = new Button("Add");
        Button editButton = new Button("Edit");
        Button deleteButton = new Button("Delete");
        Button resultButton = new Button("View Results");
        Button logoutButton = new Button("Logout");

        addButton.setOnAction(e -> addCandidate());
        editButton.setOnAction(e -> openEditCandidatePage());
        deleteButton.setOnAction(e -> openDeleteConfirmationPage());
        resultButton.setOnAction(e -> showResultPage(stage, true));
        logoutButton.setOnAction(e -> showRoleSelectionScreen(stage));

        setupTable(false);
        loadCandidates();

        layout.getChildren().addAll(
                new Label("Admin Dashboard"),
                candidateTable,
                nameField, partyField,
                addButton, editButton, deleteButton, resultButton,
                logoutButton
        );

        Scene scene = new Scene(layout, 500, 600);
        scene.getStylesheets().add(getClass().getResource("/com/example/demo/style.css").toExternalForm());
        stage.setScene(scene);
    }

    private ToggleGroup voteToggleGroup = new ToggleGroup(); // global toggle group for voter radio buttons

    private void setupTable(boolean isVoterDashboard) {
        candidateTable.getColumns().clear();

        TableColumn<Candidate, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Candidate, String> partyCol = new TableColumn<>("Party");
        partyCol.setCellValueFactory(new PropertyValueFactory<>("party"));

        candidateTable.getColumns().addAll(nameCol, partyCol);

        if (isVoterDashboard) {
            TableColumn<Candidate, RadioButton> voteCol = new TableColumn<>("Vote");

            voteCol.setCellValueFactory(cellData -> {
                Candidate candidate = cellData.getValue();
                RadioButton radioButton = new RadioButton();
                radioButton.setToggleGroup(voteToggleGroup);
                radioButton.setUserData(candidate); // Store candidate for later retrieval
                return new javafx.beans.property.SimpleObjectProperty<>(radioButton);
            });

            candidateTable.getColumns().add(voteCol);
        }

        candidateTable.setItems(candidates);
    }


    private void loadCandidates() {
        candidates.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String query = "SELECT * FROM candidates";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                candidates.add(new Candidate(rs.getInt("id"), rs.getString("name"), rs.getString("party")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addCandidate() {
        String name = nameField.getText();
        String party = partyField.getText();
        if (!name.isEmpty() && !party.isEmpty()) {
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String insertQuery = "INSERT INTO candidates (name, party) VALUES (?, ?)";
                PreparedStatement stmt = conn.prepareStatement(insertQuery);
                stmt.setString(1, name);
                stmt.setString(2, party);
                stmt.executeUpdate();
                nameField.clear();
                partyField.clear();
                loadCandidates();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void openEditCandidatePage() {
        Candidate selected = candidateTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Stage editStage = new Stage();
            VBox layout = new VBox(10);

            TextField editNameField = new TextField(selected.getName());
            TextField editPartyField = new TextField(selected.getParty());
            Button saveButton = new Button("Save");

            saveButton.setOnAction(e -> {
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                    String updateQuery = "UPDATE candidates SET name = ?, party = ? WHERE id = ?";
                    PreparedStatement stmt = conn.prepareStatement(updateQuery);
                    stmt.setString(1, editNameField.getText());
                    stmt.setString(2, editPartyField.getText());
                    stmt.setInt(3, selected.getId());
                    stmt.executeUpdate();
                    loadCandidates();
                    editStage.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            });

            layout.getChildren().addAll(new Label("Edit Candidate"), editNameField, editPartyField, saveButton);
            Scene scene = new Scene(layout, 300, 200);
            scene.getStylesheets().add(getClass().getResource("/com/example/demo/style.css").toExternalForm());
            editStage.setScene(scene);
            editStage.setTitle("Edit Candidate");
            editStage.show();
        }
    }

    private void openDeleteConfirmationPage() {
        Candidate selected = candidateTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Stage deleteStage = new Stage();
            VBox layout = new VBox(10);

            Label confirmLabel = new Label("Are you sure you want to delete " + selected.getName() + "?");
            Button confirmButton = new Button("Yes, Delete");
            Button cancelButton = new Button("Cancel");

            confirmButton.setOnAction(e -> {
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                    String deleteQuery = "DELETE FROM candidates WHERE id = ?";
                    PreparedStatement stmt = conn.prepareStatement(deleteQuery);
                    stmt.setInt(1, selected.getId());
                    stmt.executeUpdate();
                    loadCandidates();
                    deleteStage.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            });

            cancelButton.setOnAction(e -> deleteStage.close());

            layout.getChildren().addAll(confirmLabel, confirmButton, cancelButton);
            Scene scene = new Scene(layout, 300, 150);
            scene.getStylesheets().add(getClass().getResource("/com/example/demo/style.css").toExternalForm());
            deleteStage.setScene(scene);
            deleteStage.setTitle("Delete Confirmation");
            deleteStage.show();
        }
    }

    private void showVoterDashboard(Stage stage) {
        VBox layout = new VBox(10);
        setupTable(true); // true for voter
        loadCandidates();

        Button voteButton = new Button("Vote");
        Button resultButton = new Button("Show Results");
        Button logoutButton = new Button("Logout");

        voteButton.setOnAction(e -> {
            Toggle selectedToggle = voteToggleGroup.getSelectedToggle();
            if (selectedToggle != null) {
                Candidate selected = (Candidate) selectedToggle.getUserData();
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                    String checkQuery = "SELECT * FROM votes WHERE voter_id = ?";
                    PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
                    checkStmt.setInt(1, loggedInUserId);
                    ResultSet rs = checkStmt.executeQuery();

                    if (rs.next()) {
                        Alert alert = new Alert(Alert.AlertType.WARNING, "You have already voted.");
                        alert.show();
                    } else {
                        String voteQuery = "INSERT INTO votes (voter_id, candidate_id) VALUES (?, ?)";
                        PreparedStatement voteStmt = conn.prepareStatement(voteQuery);
                        voteStmt.setInt(1, loggedInUserId);
                        voteStmt.setInt(2, selected.getId());
                        voteStmt.executeUpdate();
                        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Vote cast successfully!");
                        alert.show();
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please select a candidate to vote.");
                alert.show();
            }
        });
        resultButton.setOnAction(e -> showResultPage(stage,false));
        logoutButton.setOnAction(e -> showRoleSelectionScreen(stage));

        layout.getChildren().addAll(new Label("Voter Dashboard"), candidateTable, voteButton, resultButton, logoutButton);
        Scene scene = new Scene(layout, 500, 500);
        scene.getStylesheets().add(getClass().getResource("/com/example/demo/style.css").toExternalForm());
        stage.setScene(scene);
    }

    private void showResultPage(Stage stage, boolean isAdmin) {
        VBox layout = new VBox(10);
        layout.setAlignment(Pos.CENTER);

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> {
            if (isAdmin) showAdminDashboard(stage);
            else showVoterDashboard(stage);
        });

        layout.getChildren().add(backButton);

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT result_time FROM result_timer LIMIT 1");

            LocalDateTime resultTime = rs.next()
                    ? rs.getTimestamp("result_time").toLocalDateTime()
                    : LocalDateTime.now().plusMinutes(1);

            LocalDateTime now = LocalDateTime.now();

            if (now.isBefore(resultTime)) {
                Label timerLabel = new Label();
                layout.getChildren().add(timerLabel);

                final Timeline[] timeline = new Timeline[1];
                timeline[0] = new Timeline(new KeyFrame(javafx.util.Duration.seconds(1), event -> {
                    LocalDateTime current = LocalDateTime.now();
                    long seconds = java.time.Duration.between(current, resultTime).getSeconds();

                    if (seconds <= 0) {
                        timeline[0].stop();

                        // Replace timerLabel with chart
                        layout.getChildren().remove(timerLabel);

                        try (Connection newConn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                             Statement newStmt = newConn.createStatement()) {
                            showResults(layout, newStmt);
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                    } else {
                        long hours = seconds / 3600;
                        long minutes = (seconds % 3600) / 60;
                        long secs = seconds % 60;
                        timerLabel.setText(String.format("Results available in: %02d:%02d:%02d", hours, minutes, secs));
                    }
                }));

                timeline[0].setCycleCount(Animation.INDEFINITE);
                timeline[0].play();

                if (isAdmin) {
                    DatePicker datePicker = new DatePicker(resultTime.toLocalDate());
                    Spinner<Integer> hourSpinner = new Spinner<>(0, 23, resultTime.getHour());
                    Spinner<Integer> minuteSpinner = new Spinner<>(0, 59, resultTime.getMinute());
                    Button updateButton = new Button("Update Time");

                    updateButton.setOnAction(ev -> {
                        LocalDate date = datePicker.getValue();
                        int hour = hourSpinner.getValue();
                        int minute = minuteSpinner.getValue();
                        LocalDateTime newDateTime = LocalDateTime.of(date, LocalTime.of(hour, minute));

                        try (Connection updateConn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                            PreparedStatement ps = updateConn.prepareStatement("UPDATE result_timer SET result_time = ?");
                            ps.setTimestamp(1, Timestamp.valueOf(newDateTime));
                            ps.executeUpdate();
                            showResultPage(stage, true); // Refresh view
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                    });

                    layout.getChildren().addAll(
                            new Label("Set Result Time:"),
                            datePicker, hourSpinner, minuteSpinner, updateButton
                    );
                }

            } else {
                showResults(layout, stmt);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        Scene scene = new Scene(layout, 500, 500);
        stage.setScene(scene);
        stage.setTitle("Result Page");
        stage.show();
    }

    private void showResults(VBox layout, Statement stmt) throws SQLException {
        layout.getChildren().removeIf(node -> node instanceof PieChart);  // Avoid duplicates

        Map<String, Integer> results = new HashMap<>();
        ResultSet rs = stmt.executeQuery(
                "SELECT c.name, COUNT(v.id) as votes " +
                        "FROM votes v JOIN candidates c ON v.candidate_id = c.id " +
                        "GROUP BY c.name"
        );

        while (rs.next()) {
            results.put(rs.getString("name"), rs.getInt("votes"));
        }

        ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList();
        results.forEach((name, count) -> pieData.add(new PieChart.Data(name, count)));

        PieChart chart = new PieChart(pieData);
        layout.getChildren().add(chart);
    }


}